# ztext

## install

`pip install ztext`

from source:
`pip3 install https://github.com/ZackAnalysis/ztext.git`

a nlp tool
